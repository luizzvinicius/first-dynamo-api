package com.luiz.first_dynamo_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstDynamoApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstDynamoApiApplication.class, args);
	}

}
